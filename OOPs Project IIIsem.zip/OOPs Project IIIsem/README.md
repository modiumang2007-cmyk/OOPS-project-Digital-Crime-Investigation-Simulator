# OOPS-project-Digital-Crime-Investigation-Simulator
# CaseFile — Digital Crime Investigation Simulator

A console-based case management system that models how investigative agencies track suspects, evidence, investigators, and case status — built as an Object-Oriented Programming course project.

## About

Investigations involve multiple interrelated entities — cases, suspects, evidence, and investigators — each with different behavior and strict lifecycle rules (e.g. a closed case can't be modified). CaseFile models this domain using core OOP principles rather than procedural conditionals, so that adding a new evidence type or investigator specialization means adding a class, not rewriting existing logic.

Full problem framing: [`problem-statement.md`](./problem-statement.md)

## Team

| Name | GitHub | Role |
|---|---|---|
|  Umang Modi | `modiumang2007-cmyk` | Team leader |
| Riya Vasoya | | Team member |
| Vedant Songire | | Team member |
| Pratyush Pandit| | Team member |
| Kunal Patni | | Team memeber|

## Tech Stack

- **Language:** C++ (C++17), STL only — no external dependencies for core logic
- **Build:** g++ / any standard C++ compiler
- **Diagrams:** PlantUML

## Features (v1 Scope)

- Case lifecycle management (create → assign → investigate → close)
- Polymorphic evidence handling across Digital, Physical, and Testimonial evidence types
- Investigator assignment with specialization-specific investigation behavior
- Keyword search across cases and evidence
- Report generation
- File-based save/load persistence

Out of scope for v1: GUI, database backend, multi-user login.

## Project Structure

```
.
├── README.md
├── problem-statement.md
├── CMakeLists.txt
├── cases.txt                     # runtime save/load data (gitignored)
├── docs/
│   ├── use-case-diagram.puml      # PlantUML source
│   ├── use-case-diagram.png       # rendered diagram
│   ├── use-cases.md               # full use case specifications
│   ├── class-diagram.puml / .png
│   ├── object-diagram.puml / .drawio.png
│   ├── crc-cards.md
│   └── noun-analysis.md
└── src/
    ├── Exceptions.h               # custom exception hierarchy
    ├── Person.h                   # Suspect, Witness (encapsulated records)
    ├── Evidence.h /.cpp           # abstract `Evidence` + 3 derived classes
    ├── Investigator.h /.cpp       # abstract `Investigator` + 2 derived classes
    ├── Case.h /.cpp               # case lifecycle, guards, polymorphic traversal
    ├── Report.h /.cpp             # report aggregation & serialization
    └── main.cpp                   # console menu, STL containers, save/load
```

## Use Case Diagram

![Use Case Diagram](docs/use-case-diagram.png)

Source: [`docs/use-case-diagram.puml`](docs/use-case-diagram.puml) · Full specifications: [`docs/use-cases.md`](docs/use-cases.md)

## OOP Concepts Demonstrated

Where each pillar lives in the code — handy for the viva:

| Concept | Where in the code | What to say |
|---|---|---|
| **Abstraction** | `Evidence` ([src/Evidence.h]) is an abstract base class with pure-virtual hooks: `analyzeEvidence()`, `verifyIntegrity()`, `getReportContent()`. `Investigator` ([src/Investigator.h]) similarly exposes pure-virtual `investigate()`. | "The *what* is declared in the base, the *how* is left to the derived class. Nobody can instantiate an `Evidence` — only its concrete subtypes." |
| **Inheritance** | `DigitalEvidence : Evidence`, `PhysicalEvidence : Evidence`, `TestimonialEvidence : Evidence`; `CyberInvestigator : Investigator`, `FieldInvestigator : Investigator`. | "Every subtype reuses the base's private fields (`evidenceId`, `checksum`, …) via protected accessors and adds its own state (`metadataSnapshot_`, `labResults_`, `credibilityScore_`)." |
| **Polymorphism** | `std::vector<std::unique_ptr<Evidence>>` in [src/Case.h]; `Case::analyzeAllEvidence()` loops and calls `analyzeEvidence()` ([src/Case.cpp:154]). | "One loop, no `switch` on type — the vtable picks the right implementation at runtime. Adding a 4th evidence type never touches this loop." |
| **Encapsulation** | All fields private; `Case::setStatus` chain (`changeStatus`/`closeCase`) refuses mutations once `CLOSED` ([src/Case.cpp:47]); `Evidence` exposes validated getters/setters. | "State changes only through controlled behavior — the menu can't force a closed case open. The guard is inside the class, not the UI." |
| **Exception handling** | `CaseClosedException`, `InvalidEvidenceException`, `InvalidInvestigatorException` ([src/Exceptions.h]), caught in the menu with `try/catch`. | "Domain failures are typed, not error codes. `*/Error`-free: what() carries context." |
| **STL collections** | `std::map<std::string, Case>` for O(log n) case lookup, `std::vector<std::unique_ptr<Evidence>>` for polymorphic ownership, `std::vector<std::shared_ptr<Investigator>>` for the roster. | |

## Build & Run

```bash
# Plain g++ (everything you need)
g++ -std=c++17 -Wall -Wextra src/*.cpp -o casefile
./casefile          # GNU/Linux, macOS
casefile.exe        # Windows

# Or CMake
cmake -S . -B build && cmake --build build
```

On the first run the app creates a fresh system; data is saved to `cases.txt` (menu option 13) and reloaded automatically on startup.

## Quick demo walk-through

```
1   (Create New Case)          → title "Art Heist"
3   (Add Evidence)             → Digital  "USB drive with exfil data"
11  (Register Investigator)    → Field investigator "Detective Rao"
6   (Assign Investigator)      → assign Rao to the case
4   (Analyze Evidence)         → polymorphic analysis of the digital item
7   (Generate Case Report)
9   (Close Case)
13  (Save to file)
```
A fully scripted sample transcript is given below. *(Every prompt and message shown is a literal `cout` string from the source; the sequence below uses the exact demo commands above.)*

```
  Welcome to CaseFile — Digital Crime Investigation Simulator
  (OOP demo: Abstraction • Inheritance • Polymorphism • Encapsulation)
  No save file cases.txt — starting fresh.

  ╔══════════════════════════════════════════════╗
  ║  CaseFile — Crime Investigation Simulator     ║
  ╚══════════════════════════════════════════════╝
   1. Create New Case
   2. Add Suspect / Witness to Case
   3. Add Evidence to Case
   4. Analyze Evidence
   5. Verify Evidence Integrity
   6. Assign Investigator
   7. Generate Case Report
   8. View All Cases
   9. Close Case
  10. Search
  11. Register Investigator
  12. Remove Evidence
  13. Save to file
  14. Load from file
   0. Exit
  ─────────────────────────────────────────────
  Choice: 1
  Case title: Art Heist
  Created case CASE-1 — "Art Heist"

  ... (menu) Choice: 3
  ── Current Cases ──
  [CASE-1] Art Heist  Status: OPEN  Evidence: 0  Suspects: 0
  Enter case ID: CASE-1

  Evidence type:
    1. Digital      (e.g. disk image, logs)
    2. Physical     (e.g. weapon, fingerprints)
    3. Testimonial  (e.g. witness statement)
  Select: 1
  Description: USB drive with exfil data
  Collected by: Detective Rao
  Metadata snapshot (e.g. file hash, image path): file_hash=A3F9C2
  Evidence EVID-1000 (Digital) added to case CASE-1.

  ... (menu) Choice: 11
  Investigator type:
    1. Cyber
    2. Field
  Select: 2
  Investigator name: Detective Rao
  Registered Detective Rao as Field investigator.

  ... (menu) Choice: 6
  Enter case ID: CASE-1
  ── Investigator Roster ──
   1. Detective Rao (Field)  Caseload: 0
  Select investigator: 1
  Investigator "Detective Rao" assigned to case CASE-1. Status -> UNDER_INVESTIGATION.

  ... (menu) Choice: 4
  Enter case ID: CASE-1
  ── Analyzing all evidence for case CASE-1 ──
  >> [DIGITAL] Scanning metadata snapshot (16 bytes) …
  >> File-system artifacts cross-referenced.
  [Evidence EVID-1000] Analysis complete.

  ... (menu) Choice: 7
  Enter case ID: CASE-1
  [Field Investigator Detective Rao] Initiating on-site procedure:
    1. Securing the crime scene perimeter …
    2. Documenting physical evidence in situ …
    3. Collecting witness statements on record …
    4. Coordinating with forensics lab for chain of custody …
    >> Field investigation scan complete.

  ╔══════════════════════════════════════════════╗
  ║           CASE REPORT                       ║
  ╚══════════════════════════════════════════════╝
  Case ID   : CASE-1
  Title     : Art Heist
  Status    : UNDER_INVESTIGATION
  Opened    : 2026-09-16
  Closed    : —

  Investigator: Detective Rao (Field)

  ── Suspects (0) ──
  ── Witnesses (0) ──
  ── Evidence (1) ──
    • [Digital Evidence EVID-1000] USB drive with exfil data | Collected by: Detective Rao | Metadata: file_hash=A3F9C2 | Analysis: Digital analysis complete — metadata: file_hash=A3F9C2

  ... (menu) Choice: 9
  Enter case ID: CASE-1
  Case CASE-1 has been CLOSED.

  ... (menu) Choice: 13
  Saved 1 case(s) to cases.txt.

  ... (menu) Choice: 0
  Goodbye. Investigation records kept secure.
```

## Documentation

- [Problem Statement](./problem-statement.md)
- [Use Case Specifications](docs/use-cases.md)
- [Use Case Diagram (PlantUML source)](docs/use-case-diagram.puml)
